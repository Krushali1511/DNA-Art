
eye_colors = {
    'Brown Eyes': 'AATC',
    'Green Eyes': 'TTCA',
    'Blue Eyes': 'CGAT',
    'Hazel Eyes': 'CTAG',
    'Amber Eyes': 'TACG',
    'Gray Eyes': 'GCTA',
}
hair_colors = {
    'Blonde Hair': 'AGCT',
    'Brown Hair': 'TCGA',
    'Red Hair': 'GTCA',
    'Black Hair': 'ACGT',
    'Auburn Hair': 'TGGC'
}
skin_colors = {
    'Pale Skin': 'GCTG',
    'Medium Skin': 'GGGC',
    'Dark Skin': 'CCGG',
    'Olive Skin': 'ATCC',
    'Tan Skin': 'CTTA'
}
hair_textures = {
    'Straight Hair': 'TTGC',
    'Curly Hair': 'AAAA',
    'Wavy Hair': 'GGTT',
    'Kinky Hair': 'GAAT',
    'Loose Waves': 'TCCG'
}
heights = {
    'Tall': 'GCTA',
    'Average Height': 'ATTC',
    'Short': 'CCTA',
    'Petite': 'TTAC',
    'Above Average Height': 'GATT'
}
facial_structures = {
    'Oval Face': 'GTTA',
    'Round Face': 'AGGC',
    'Square Face': 'TGCA',
    'Heart-Shaped Face': 'TGTC',
    'Diamond-Shaped Face': 'GGGT'
}
age_appearances = {
    'Looks Young': 'GGTG',
    'Looks Old': 'TGGG',
    'Ageless': 'CGGG',
    'Premature Aging': 'GTGC',
    'Delayed Aging': 'CCCC'
}
nose_types= {
    'Straight Nose': 'GCGA',
    'Hooked Nose': 'ATAC',
    'Flat Nose': 'CGAA',
    'Pointed Nose': 'TTTC',
    'Wide Nose': 'GAGG'
}
lip_shapes = {
    'Full Lips': 'GAAA',
    'Thin Lips': 'ATAA',
    'Heart-Shaped Lips': 'TGTA',
    'Wide Lips': 'TGAT',
    'Defined Cupid\'s Bow': 'GCGT'
}
body_types = {
    'Muscular': 'ATGC',
    'Lean': 'CGTA',
    'Athletic': 'TGAC',
    'Petite': 'GAGT',
    'Curvy': 'TTAA'
}
