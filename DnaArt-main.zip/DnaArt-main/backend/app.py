from flask import Flask
from flask_cors import CORS
from dotenv import load_dotenv
import os

load_dotenv()
app = Flask(__name__)
CORS(app, resources={r"/analyze-dna": {"origins": os.getenv("Frontend_API_URL")}})
API_KEY = os.getenv("API_KEY")

def analyze_dna(user_dna):
    url = "https://api.perplexity.ai/chat/completions"
    if len(user_dna) != 40 or not all(base in "ATCG" for base in user_dna):
        return "Error: Sequence must be 40 characters long and contain only A, T, C, G."

    # Split into 10 parts of 4 characters each
    parts = [user_dna[i:i+4] for i in range(0, 40, 4)]

    # Mapping dictionaries to traits
    trait_mappings = [
        # ...existing code...
    ]