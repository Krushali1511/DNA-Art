from dotenv import load_dotenv
import os

# Load the .env file
load_dotenv()

# Access variables
api_key = os.getenv("API_KEY")
frontend_url = os.getenv("Frontend_API_URL")

print(f"API Key: {api_key}")
print(f"Frontend URL: {frontend_url}")
